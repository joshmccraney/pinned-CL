#!/bin/bash

rm -r processor*
rm -r 0
cp -r 0.orig 0
#funkySetFields -time 0
setFields
decomposePar
mpirun -np 16 interFoam -parallel
#mpirun -np 16 bfInterFoam -parallel